// src/App.js
import React from 'react';
import RouterComponent from './Router'; // Import the RouterComponent

function App() {
  return (
    <RouterComponent />
  );
}

export default App;
