import React from 'react';
import Slider from 'react-slick'; // Import Slider from react-slick

import capagg from './assets/capagg.jpg';
import corn from './assets/corn.jpg';
import potato from './assets/potato.jpg';
import pum from './assets/pum.jpg';
import spinach from './assets/spinach.jpg';

import Layout from './components/Layout';
 // Import the Layout component

const Home = () => {
  const containerStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    padding: '20px',
    minHeight: '80vh', // Ensure minimum height to push footer to the bottom
  };

  const headingStyle = {
    textAlign: 'center',
    margin: '20px 0',
  };

  const slideContainerStyle = {
    display: 'flex',
    flexDirection: 'row', // Row layout for text and image side by side
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '20px',
  };

  const textContainerStyle = {
    flex: 1,
    paddingRight: '20px', // Space between text and image
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center', // Center text vertically
    height: '100%', // Make sure the text container takes full height of the slide
  };

  const imageContainerStyle = {
    flex: 3,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  };

  const imageStyle = {
    width: '100%', // Set width to 100% to make the image fill the container
    maxWidth: '900px', // Optionally set a maximum width
    height: '300px', // Increase height as needed
    borderRadius: '20px',
    boxShadow: '0 4px 8px rgba(255, 223, 0, 0.5)',
    transition: 'transform 0.2s, box-shadow 0.2s', // Smooth transition for hover effect
    margin: '0 10px', // Add a 20px gap (10px on each side) between images
  };

  // Slider settings
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 3, // Show one slide at a time for larger images
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 2000,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };

  const produceInfo = [
    { image: capagg, text: 'Fresh Cabbage' },
    { image: corn, text: 'Sweet Corn' },
    { image: potato, text: 'Organic Potatoes' },
    { image: pum, text: 'Pumpkin' },
    { image: spinach, text: 'Fresh Spinach' },
  ];

 

  return (
    <Layout>
      <div style={containerStyle}>
        <h1 style={headingStyle}>Welcome to Our Supermarket!</h1>
        <p style={headingStyle}>
          Explore a variety of fresh products and unbeatable offers.
        </p>
        <div style={{ width: '90%', maxWidth: '1200px' }}>
          <Slider {...settings}>
            {produceInfo.map((item, index) => (
              <div 
                key={index} 
                style={slideContainerStyle}
              >
                <div style={textContainerStyle}>
                  <h2>{item.text}</h2>
                </div>
                <div style={imageContainerStyle}>
                  <img src={item.image} alt={item.text} style={imageStyle} />
                </div>
              </div>
            ))}
          </Slider>
        </div>
      </div>
      
    </Layout>
  );
};



export default Home;