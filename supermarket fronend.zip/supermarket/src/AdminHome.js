import React from 'react';
import AdminLayout from './components/AdminLayout';

const AdminHome = () => {
    const containerStyle = {
        padding: '20px',
        backgroundColor: '#f4f4f9',
        borderRadius: '8px',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    };

    const sectionStyle = {
        marginBottom: '20px',
        padding: '20px',
        backgroundColor: '#fff',
        borderRadius: '8px',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    };

    const titleStyle = {
        fontSize: '24px',
        fontWeight: 'bold',
        marginBottom: '10px',
    };

    const textStyle = {
        fontSize: '16px',
    };

    return (
        <AdminLayout>
            <div style={containerStyle}>
                <div style={sectionStyle}>
                    <h2 style={titleStyle}>Welcome to the Admin Panel</h2>
                    <p style={textStyle}>Manage your supermarket efficiently with the admin tools provided below.</p>
                </div>
                <div style={sectionStyle}>
                    <h3 style={titleStyle}>Dashboard Overview</h3>
                    <p style={textStyle}>Get a quick overview of the key metrics and performance indicators of your supermarket.</p>
                </div>
                <div style={sectionStyle}>
                    <h3 style={titleStyle}>Recent Activities</h3>
                    <p style={textStyle}>Keep track of the recent activities and changes made in the system.</p>
                </div>
                <div style={sectionStyle}>
                    <h3 style={titleStyle}>Manage Products</h3>
                    <p style={textStyle}>Add, edit, or remove products from your inventory.</p>
                </div>
                <div style={sectionStyle}>
                    <h3 style={titleStyle}>Orders</h3>
                    <p style={textStyle}>View and manage customer orders.</p>
                </div>
                <div style={sectionStyle}>
                    <h3 style={titleStyle}>Customer Management</h3>
                    <p style={textStyle}>Manage customer information and support.</p>
                </div>
                <div style={sectionStyle}>
                    <h3 style={titleStyle}>Settings</h3>
                    <p style={textStyle}>Adjust system settings and preferences.</p>
                </div>
            </div>
        </AdminLayout>
    );
};

export default AdminHome;
