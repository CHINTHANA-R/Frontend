import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import logo from '../assets/fblogo.jpg';

const Header = () => {
    const [isDropdownOpen, setIsDropdownOpen] = useState(false);
    const [isLoginDropdownOpen, setIsLoginDropdownOpen] = useState(false);

    const headerStyle = {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        padding: '15px 30px',
        backgroundColor: '#343a40',
        color: '#fff',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    };

    const topSectionStyle = {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        width: '100%',
        maxWidth: '1200px',
        marginBottom: '20px',
    };

    const logoContainerStyle = {
        display: 'flex',
        alignItems: 'center',
        gap: '10px',
    };

    const logoStyle = {
        height: '60px',
    };

    const appNameStyle = {
        color: '#ffdd57',
        fontSize: '20px',
    };

    const searchBarStyle = {
        display: 'flex',
        alignItems: 'center',
        flex: '1',
        maxWidth: '600px',
    };

    const inputStyle = {
        padding: '10px',
        marginRight: '10px',
        border: '1px solid #ccc',
        borderRadius: '4px',
        flex: '1',
    };

    const buttonStyle = {
        padding: '10px 15px',
        backgroundColor: '#ffdd57',
        color: '#007bff',
        border: 'none',
        borderRadius: '4px',
        cursor: 'pointer',
        fontWeight: 'bold',
        transition: 'background-color 0.3s',
    };

    const buttonHoverStyle = {
        backgroundColor: '000000',
    };

    const cartStyle = {
        color: '#ffdd57',
        fontSize: '18px',
        cursor: 'pointer',
        marginLeft: '10px',
    };

    const navContainerStyle = {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        width: '100%',
    };

    const navStyle = {
        listStyle: 'none',
        display: 'flex',
        gap: '100px',
        margin: '0',
        padding: '0',
    };

    const linkStyle = {
        textDecoration: 'none',
        padding: '40px',
        color: '#fff',
        fontWeight: 'bold',
        fontSize: '16px',
        gap: '200px',
        transition: 'color 0.3s',
    };

    const linkHoverStyle = {
        color: '#ffdd57',
    };

    const dropdownStyle = {
        position: 'absolute',
        top: '100%',
        left: '0',
        backgroundColor: '#343a40',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
        zIndex: 1,
    };

    const dropdownItemStyle = {
        padding: '10px 20px',
        color: '#fff',
        textDecoration: 'none',
        display: 'block',
    };

    const dropdownItemHoverStyle = {
        backgroundColor: '#ffdd57',
    };

    return (
        <header style={headerStyle}>
            <div style={topSectionStyle}>
                <div style={logoContainerStyle}>
                    <Link to="/">
                        <img src={logo} alt="Supermarket Logo" style={logoStyle} />
                    </Link>
                    <div style={appNameStyle}>Supermarket</div>
                </div>
                <div style={searchBarStyle}>
                    <input type="text" placeholder="Search products..." style={inputStyle} />
                    <button
                        type="submit"
                        style={buttonStyle}
                        onMouseOver={(e) => (e.target.style.backgroundColor = buttonHoverStyle.backgroundColor)}
                        onMouseOut={(e) => (e.target.style.backgroundColor = buttonStyle.backgroundColor)}
                    >
                        Search
                    </button>
                    <div style={cartStyle}>
                        <i className="fa fa-shopping-cart"></i>
                    </div>
                </div>
            </div>
            <nav style={navContainerStyle}>
                <ul style={navStyle}>
                    <li
                        onMouseEnter={() => setIsDropdownOpen(true)}
                        onMouseLeave={() => setIsDropdownOpen(false)}
                        style={{ position: 'relative' }}
                    >
                        <Link
                            to="#"
                            style={linkStyle}
                            onMouseOver={(e) => (e.target.style.color = linkHoverStyle.color)}
                            onMouseOut={(e) => (e.target.style.color = linkStyle.color)}
                        >
                            Products
                        </Link>
                        {isDropdownOpen && (
                            <div style={dropdownStyle}>
                                <Link
                                    to="/vegetables"
                                    style={dropdownItemStyle}
                                    onMouseOver={(e) => (e.target.style.backgroundColor = dropdownItemHoverStyle.backgroundColor)}
                                    onMouseOut={(e) => (e.target.style.backgroundColor = dropdownStyle.backgroundColor)}
                                >
                                    Vegetables
                                </Link>
                                <Link
                                    to="/fruits"
                                    style={dropdownItemStyle}
                                    onMouseOver={(e) => (e.target.style.backgroundColor = dropdownItemHoverStyle.backgroundColor)}
                                    onMouseOut={(e) => (e.target.style.backgroundColor = dropdownStyle.backgroundColor)}
                                >
                                    Fruits
                                </Link>
                                <Link
                                    to="/grocery"
                                    style={dropdownItemStyle}
                                    onMouseOver={(e) => (e.target.style.backgroundColor = dropdownItemHoverStyle.backgroundColor)}
                                    onMouseOut={(e) => (e.target.style.backgroundColor = dropdownStyle.backgroundColor)}
                                >
                                    Grocery
                                </Link>
                                <Link
                                    to="/dairy"
                                    style={dropdownItemStyle}
                                    onMouseOver={(e) => (e.target.style.backgroundColor = dropdownItemHoverStyle.backgroundColor)}
                                    onMouseOut={(e) => (e.target.style.backgroundColor = dropdownStyle.backgroundColor)}
                                >
                                    Dairy Products
                                </Link>
                                <Link
                                    to="/chocolates"
                                    style={dropdownItemStyle}
                                    onMouseOver={(e) => (e.target.style.backgroundColor = dropdownItemHoverStyle.backgroundColor)}
                                    onMouseOut={(e) => (e.target.style.backgroundColor = dropdownStyle.backgroundColor)}
                                >
                                    Chocolates
                                </Link>
                            </div>
                        )}
                    </li>
                    <li>
                        <Link
                            to="/contact"
                            style={linkStyle}
                            onMouseOver={(e) => (e.target.style.color = linkHoverStyle.color)}
                            onMouseOut={(e) => (e.target.style.color = linkStyle.color)}
                        >
                            Contact Us
                        </Link>
                    </li>
                    <li>
                        <Link
                            to="/about"
                            style={linkStyle}
                            onMouseOver={(e) => (e.target.style.color = linkHoverStyle.color)}
                            onMouseOut={(e) => (e.target.style.color = linkStyle.color)}
                        >
                            About Us
                        </Link>
                    </li>
                    <li>
                        <Link
                            to="/cart"
                            style={linkStyle}
                            onMouseOver={(e) => (e.target.style.color = linkHoverStyle.color)}
                            onMouseOut={(e) => (e.target.style.color = linkStyle.color)}
                        >
                            Cart
                        </Link>
                    </li>
                    <li
                        onMouseEnter={() => setIsLoginDropdownOpen(true)}
                        onMouseLeave={() => setIsLoginDropdownOpen(false)}
                        style={{ position: 'relative' }}
                    >
                        <Link
                            to="#"
                            style={linkStyle}
                            onMouseOver={(e) => (e.target.style.color = linkHoverStyle.color)}
                            onMouseOut={(e) => (e.target.style.color = linkStyle.color)}
                        >
                            Login/Sign Up
                        </Link>
                        {isLoginDropdownOpen && (
                            <div style={dropdownStyle}>
                                <Link
                                    to="/login"
                                    style={dropdownItemStyle}
                                    onMouseOver={(e) => (e.target.style.backgroundColor = dropdownItemHoverStyle.backgroundColor)}
                                    onMouseOut={(e) => (e.target.style.backgroundColor = dropdownStyle.backgroundColor)}
                                >
                                    User
                                </Link>
                                <Link
                                    to="/adminlogin"
                                    style={dropdownItemStyle}
                                    onMouseOver={(e) => (e.target.style.backgroundColor = dropdownItemHoverStyle.backgroundColor)}
                                    onMouseOut={(e) => (e.target.style.backgroundColor = dropdownStyle.backgroundColor)}
                                >
                                    Admin
                                </Link>
                            </div>
                        )}
                    </li>
                </ul>
            </nav>
        </header>
    );
};

export default Header;
