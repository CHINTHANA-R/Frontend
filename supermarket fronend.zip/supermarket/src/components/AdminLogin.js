import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AdminLayout from './AdminLayout';

const AdminLogin = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const validEmail = 'admin@supermarket.com';
    const validPassword = 'admin123';

    const formContainerStyle = {
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '100%',
        marginTop: '30px', 
    };

    const formStyle = {
        backgroundColor: '#fff',
        padding: '20px',
        borderRadius: '8px',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
        width: '300px',
        textAlign: 'center',
    };

    const inputStyle = {
        width: '100%',
        padding: '10px',
        margin: '10px 0',
        border: '1px solid #ccc',
        borderRadius: '4px',
    };

    const buttonStyle = {
        width: '100%',
        padding: '10px',
        backgroundColor: '#007bff',
        color: '#fff',
        border: 'none',
        borderRadius: '4px',
        cursor: 'pointer',
        fontWeight: 'bold',
    };

    const errorStyle = {
        color: 'red',
        marginTop: '10px',
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (email === validEmail && password === validPassword) {
            console.log('Login successful');
            setError('');
            navigate('/adminhome'); // Redirect to AdminHome.js page
        } else {
            setError('Invalid email or password');
        }
    };

    return (
        <AdminLayout>
            <div style={formContainerStyle}>
                <div style={formStyle}>
                    <h2>Admin Login</h2>
                    <form onSubmit={handleSubmit}>
                        <input
                            type="email"
                            placeholder="Email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            style={inputStyle}
                            required
                        />
                        <input
                            type="password"
                            placeholder="Password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            style={inputStyle}
                            required
                        />
                        <button type="submit" style={buttonStyle}>
                            Login
                        </button>
                        {error && <div style={errorStyle}>{error}</div>}
                    </form>
                </div>
            </div>
        </AdminLayout>
    );
};

export default AdminLogin;
