    import React, { useState } from 'react';
    import { Link } from 'react-router-dom';
    import logo from '../assets/logo.jpg';

    const Header = () => {
    const [dropdownVisible, setDropdownVisible] = useState(false);

    const commonStyle = {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: '10px 20px',
        backgroundColor: '#343a40',
        color: '#ffdd57',
        height: '80px',
        width: '100%',
        boxSizing: 'border-box',
    };

    const logoStyle = {
        display: 'flex',
        alignItems: 'center',
    };

    const navStyle = {
        display: 'flex',
    };

    const linkStyle = {
        color: '#ffdd57',
        textDecoration: 'none',
        margin: '0 10px',
        position: 'relative',
    };

    const dropdownStyle = {
        position: 'absolute',
        top: '100%',
        left: '0',
        backgroundColor: '#343a40',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
        zIndex: '1000',
    };

    const dropdownItemStyle = {
        padding: '10px',
        color: '#ffdd57',
        textDecoration: 'none',
        display: 'block',
    };
    

    const handleMouseEnter = () => {
        setDropdownVisible(true);
    };

    const handleMouseLeave = () => {
        setDropdownVisible(false);
    };

    return (
        <header style={commonStyle}>
        <div style={logoStyle}>
            <Link to="/" style={{ textDecoration: 'none', color: '#ffdd57', display: 'flex', alignItems: 'center' }}>
            <img src={logo} alt="Supermarket Logo" style={{ height: '40px', marginRight: '10px' }} />
            <span>Supermarket Admin</span>
            </Link>
        </div>
        <nav style={navStyle}>
            <Link to="/" style={linkStyle}>Dashboard</Link>
            <div 
            style={linkStyle}
            onMouseEnter={handleMouseEnter}
            onMouseLeave={handleMouseLeave}
            >
            <span>Products</span>
            {dropdownVisible && (
                <div style={dropdownStyle}>
                <Link to="/dairy" style={dropdownItemStyle}>Dairy Products</Link>
                <Link to="/chocolates" style={dropdownItemStyle}>Snacks</Link>
                <Link to="/fruits" style={dropdownItemStyle}>Fruits</Link>
                <Link to="/vegetables" style={dropdownItemStyle}>Vegetables</Link>
                <Link to="/grocery" style={dropdownItemStyle}>Grocery</Link>
                </div>
            )}
            </div>
            <Link to="/orders" style={linkStyle}>Orders</Link>
            <Link to="/customers" style={linkStyle}>Customers</Link>
            <Link to="/reports" style={linkStyle}>Reports</Link>
            <Link to="/logout" style={linkStyle}>Logout</Link>
        </nav>
        </header>
    );
    };

    export default Header;