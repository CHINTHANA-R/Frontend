import React from 'react';
import AdminHeader from './AdminHeader';
import AdminFooter from './AdminFooter';

const AdminLayout = ({ children }) => {
    const layoutStyle = {
        display: 'flex',
        flexDirection: 'column',
        minHeight: '100vh',
    };

    const contentStyle = {
        flex: '1',
        padding: '20px',
    };

    return (
        <div style={layoutStyle}>
            <AdminHeader />
            <main style={contentStyle}>
                {children}
            </main>
            <AdminFooter />
        </div>
    );
};

export default AdminLayout;
