import React from 'react';

const AdminFooter = () => {
    const footerStyle = {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        padding: '15px 30px',
        backgroundColor: '#343a40',
        color: '#fff',
        position: 'fixed',
        width: '100%',
        bottom: '0',
        boxShadow: '0 -4px 8px rgba(0, 0, 0, 0.1)',
        textAlign: 'center',
    };

    const linkStyle = {
        color: '#ffdd57',
        textDecoration: 'none',
        margin: '0 10px',
        transition: 'color 0.3s',
    };

    const linkHoverStyle = {
        color: '#007bff',
    };

    const textStyle = {
        margin: '10px 0',
    };

    const currentYear = new Date().getFullYear();

    return (
        <footer style={footerStyle}>
            <div style={{ marginBottom: '10px' }}>
                <a
                    href="/admin/terms"
                    style={linkStyle}
                    onMouseOver={(e) => (e.target.style.color = linkHoverStyle.color)}
                    onMouseOut={(e) => (e.target.style.color = linkStyle.color)}
                >
                    Terms of Service
                </a>
                |
                <a
                    href="/admin/privacy"
                    style={linkStyle}
                    onMouseOver={(e) => (e.target.style.color = linkHoverStyle.color)}
                    onMouseOut={(e) => (e.target.style.color = linkStyle.color)}
                >
                    Privacy Policy
                </a>
                |
                <a
                    href="/admin/contact"
                    style={linkStyle}
                    onMouseOver={(e) => (e.target.style.color = linkHoverStyle.color)}
                    onMouseOut={(e) => (e.target.style.color = linkStyle.color)}
                >
                    Contact Support
                </a>
            </div>
            <p style={textStyle}>© {currentYear} Supermarket Admin Panel. All rights reserved.</p>
        </footer>
    );
};

export default AdminFooter;
