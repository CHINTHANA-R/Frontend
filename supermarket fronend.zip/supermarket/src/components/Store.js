import { createStore } from 'redux';
import { Provider, useSelector } from 'react-redux';
import React from 'react';
import ReactDOM from 'react-dom';
import App from './App'; // Your main App component
import { Header } from './Header'; // Your Header component

// Initial state
const initialState = {
    user: null,
};

// Reducer
const rootReducer = (state = initialState, action) => {
    switch (action.type) {
        case 'SET_USER':
            return { ...state, user: action.payload };
        default:
            return state;
    }
};

// Store
const store = createStore(rootReducer);

// App with Provider
const MainApp = () => (
    <Provider store={store}>
        <App />
    </Provider>
);

ReactDOM.render(<MainApp />, document.getElementById('root'));
