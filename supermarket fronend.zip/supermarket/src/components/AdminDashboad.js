// AdminDashboard.js

import React, { useState } from 'react';
import { Line, Bar } from 'react-chartjs-2';
import { Chart as ChartJS, Title, Tooltip, Legend, LineElement, PointElement, BarElement, CategoryScale, LinearScale } from 'chart.js';
import AdminLayout from './AdminLayout';

// Register required Chart.js components
ChartJS.register(
    Title,
    Tooltip,
    Legend,
    LineElement,
    PointElement,
    BarElement,
    CategoryScale,
    LinearScale
);

const AdminDashboard = () => {
    const [showSalesChart, setShowSalesChart] = useState(true);

    const dashboardStyle = {
        padding: '20px',
        backgroundColor: '#f4f4f9',
        flex: 1, // Make it grow to fill available space
    };

    const cardContainerStyle = {
        display: 'flex',
        flexWrap: 'wrap',
        gap: '20px',
        justifyContent: 'space-around',
        marginBottom: '20px',
    };

    const cardStyle = {
        backgroundColor: '#fff',
        padding: '20px',
        borderRadius: '8px',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
        width: '200px',
        textAlign: 'center',
    };

    const titleStyle = {
        fontSize: '18px',
        fontWeight: 'bold',
        marginBottom: '10px',
    };

    const valueStyle = {
        fontSize: '24px',
        color: '#007bff',
        fontWeight: 'bold',
    };

    const chartContainerStyle = {
        marginTop: '20px',
        padding: '20px',
        backgroundColor: '#fff',
        borderRadius: '8px',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    };

    const buttonStyle = {
        padding: '10px 20px',
        backgroundColor: '#007bff',
        color: '#fff',
        border: 'none',
        borderRadius: '4px',
        cursor: 'pointer',
        fontWeight: 'bold',
        transition: 'background-color 0.3s',
    };

    const buttonHoverStyle = {
        backgroundColor: '#0056b3',
    };

    const salesData = {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [
            {
                label: 'Monthly Sales',
                data: [300, 500, 400, 600, 700, 800],
                borderColor: '#007bff',
                backgroundColor: 'rgba(0, 123, 255, 0.2)',
                fill: true,
            },
        ],
    };

    const ordersData = {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [
            {
                label: 'Monthly Orders',
                data: [20, 30, 25, 40, 45, 50],
                borderColor: '#28a745',
                backgroundColor: 'rgba(40, 167, 69, 0.2)',
                fill: true,
            },
        ],
    };

    return (
        <AdminLayout>
            <div style={dashboardStyle}>
                <h2>Admin Dashboard</h2>
                <div style={cardContainerStyle}>
                    <div style={cardStyle}>
                        <div style={titleStyle}>Total Products</div>
                        <div style={valueStyle}>150</div>
                    </div>
                    <div style={cardStyle}>
                        <div style={titleStyle}>Total Orders</div>
                        <div style={valueStyle}>45</div>
                    </div>
                    <div style={cardStyle}>
                        <div style={titleStyle}>Total Sales</div>
                        <div style={valueStyle}>$3,500</div>
                    </div>
                    <div style={cardStyle}>
                        <div style={titleStyle}>New Customers</div>
                        <div style={valueStyle}>12</div>
                    </div>
                </div>
                <div style={chartContainerStyle}>
                    <button
                        style={buttonStyle}
                        onMouseOver={(e) => (e.target.style.backgroundColor = buttonHoverStyle.backgroundColor)}
                        onMouseOut={(e) => (e.target.style.backgroundColor = buttonStyle.backgroundColor)}
                        onClick={() => setShowSalesChart(!showSalesChart)}
                    >
                        {showSalesChart ? 'Show Orders Chart' : 'Show Sales Chart'}
                    </button>
                    {showSalesChart ? (
                        <Line data={salesData} />
                    ) : (
                        <Bar data={ordersData} />
                    )}
                </div>
            </div>
        </AdminLayout>
    );
};

export default AdminDashboard;